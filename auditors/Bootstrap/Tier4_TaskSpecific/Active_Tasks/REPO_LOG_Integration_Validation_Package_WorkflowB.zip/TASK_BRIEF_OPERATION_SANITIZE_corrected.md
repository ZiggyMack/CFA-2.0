╔════════════════════════════════════════════════════╗
║          TASK BRIEF: OPERATION SANITIZE            ║
║      Tier 3 Recursive Axioms Review System         ║
╠════════════════════════════════════════════════════╣
║  Created: 2025-10-29                               ║
║  Priority: HIGH - Core validation loop             ║
║  Type: Repeatable Validation Command               ║
║  Status: Ready for implementation                  ║
╚════════════════════════════════════════════════════╝

## 📋 MISSION OVERVIEW

**Objective:** Create a repeatable command system where Tier 3 Axioms Reviewers can perform comprehensive "inside and out, upside and down" analysis of the entire CFA 2.0 repository, producing actionable update packages as compressed deliverables.

**The Vision:** 
```bash
> Execute: Operation Sanitize
> Output: sanitize_output_round_01.zip
> Input to next Claude: sanitize_output_round_01.zip
> Output: sanitize_output_round_02.zip
> Repeat until: final_update_package.zip
```

**Core Principle:** Full recursive validation where each Tier 3 Claude receives the previous round's output, validates it, adds their findings, and passes forward until convergence.

---

## 🎯 OPERATION SANITIZE COMMAND

### Command Structure

```markdown
OPERATION SANITIZE - ROUND [N]

You are Tier 3 Axioms Reviewer for Round [N].

Your mission:
1. Read ENTIRE repository (CFA-2.0/)
2. Review ALL previous validation reports (if Round > 1)
3. Identify EVERY issue, inconsistency, improvement
4. Cross-reference ALL interdependent documents
5. Validate ALL previous reviewer findings
6. Add YOUR unique findings
7. Package EVERYTHING for next round

Input: 
- CFA-2.0/ repository (full)
- [If Round > 1] sanitize_output_round_[N-1].zip

Output:
- sanitize_output_round_[N].zip containing:
  * validation_report_round_[N].md
  * identified_issues_round_[N].md
  * proposed_updates_round_[N].md
  * cross_validation_round_[N].md (validates previous rounds)
  * interdependencies_map_round_[N].md
  * priority_actions_round_[N].md

Constraints:
- Work type: HEAVY (complex multi-file analysis)
- Pacing: 1-2 files per minute recommended
- Handoff: After 15-20 files OR 60 minutes
- Plan for MULTIPLE rounds from start

Execute: Full recursive review
```

---

## 📊 ROUND STRUCTURE

### Round 1: Initial Discovery
**Input:** CFA-2.0/ repository only
**Claude:** Fresh Tier 3 instance
**Focus:** Comprehensive first pass
**Output:** All issues found, no assumptions about previous work

### Round 2: Validation + Extension
**Input:** CFA-2.0/ + Round 1 output
**Claude:** Fresh Tier 3 instance
**Focus:** Validate Round 1 findings, add new discoveries
**Output:** Confirmed issues + new findings + corrections to Round 1

### Round 3+: Convergence
**Input:** CFA-2.0/ + All previous outputs
**Claude:** Fresh Tier 3 instance
**Focus:** Validate all previous rounds, identify remaining gaps
**Output:** Diminishing new findings → convergence signal

### Final Round: Synthesis
**Input:** CFA-2.0/ + All previous outputs
**Claude:** Fresh Tier 3 instance  
**Focus:** Synthesize all findings into final update package
**Output:** `final_update_package.zip` ready for implementation

---

## 📁 OUTPUT PACKAGE STRUCTURE

### Each Round Produces:

```
sanitize_output_round_[N].zip
├── validation_report_round_[N].md
│   ├── Executive Summary
│   ├── Files Reviewed (all 28+ files)
│   ├── Cross-references Validated
│   ├── Consistency Checks
│   └── Overall Assessment
│
├── identified_issues_round_[N].md
│   ├── Critical Issues (must fix)
│   ├── Major Issues (should fix)
│   ├── Minor Issues (nice to fix)
│   ├── Inconsistencies Found
│   └── Missing Elements
│
├── proposed_updates_round_[N].md
│   ├── Specific File Updates (with line numbers)
│   ├── New Content Needed
│   ├── Deletions Recommended
│   ├── Restructuring Suggestions
│   └── Priority Order
│
├── cross_validation_round_[N].md
│   ├── Round [N-1] Findings: Confirmed / Rejected / Modified
│   ├── Round [N-2] Findings: Status
│   ├── Convergence Analysis
│   └── Remaining Disagreements
│
├── interdependencies_map_round_[N].md
│   ├── Document Relationships
│   ├── Cross-reference Matrix
│   ├── Update Impact Analysis
│   └── Cascade Effects Identified
│
└── priority_actions_round_[N].md
    ├── Must Do First (blocking issues)
    ├── Should Do Next (major improvements)
    ├── Can Do Later (polish)
    └── Recommended Round [N+1] Focus
```

---

## 🔬 TIER 3 AXIOMS REVIEWER PROTOCOL

### Phase 1: Repository Scan (Paced)

**Objective:** Read all files systematically

**Files to review:**
```
Core Framework (5 files):
1. MISSION_DEFAULT.md
2. AUDITORS_AXIOMS.md  
3. TRUST_PROTOCOL.md
4. VUDU_COORDINATION_FRAMEWORK.md
5. POINTING_RULE_GUIDE.md

Deployment v3.8.0 (10 files):
6-15. All v3.8.0 deployment documents

Deployment v3.7.2 (28 files):
16-43. All v3.7.2 deployment documents

Documentation (variable):
44+. All README, CHANGELOG, validation reports, etc.
```

**Pacing:**
- Read 1-2 files per 1-2 minutes
- Report context after every 5 files
- Create checkpoint after every 10 files
- Plan for handoff after 15-20 files if needed

**If handoff needed:**
- Create comprehensive handoff document
- Include all findings to date
- Next Claude continues from checkpoint
- Findings accumulate across handoffs

### Phase 2: Cross-Reference Validation

**Objective:** Verify all interdependencies

**Check:**
- Version references (are all v3.8.0 references consistent?)
- File references (do all links point to existing files?)
- Concept definitions (are terms used consistently?)
- Process flows (do described workflows match actual structure?)
- Tiering logic (does Tier 1/2/3/4 usage align?)

**Output:** Interdependencies map

### Phase 3: Issue Identification

**Objective:** Find everything wrong or improvable

**Categories:**
1. **Critical:** Blocks system function
2. **Major:** Significant inconsistency or gap
3. **Minor:** Small improvement or polish
4. **Inconsistency:** Conflicting information
5. **Missing:** Should exist but doesn't

**Output:** Comprehensive issues list

### Phase 4: Proposal Generation

**Objective:** Specific actionable updates

**Format:**
```
File: /path/to/file.md
Line: 42-45
Current: [exact text]
Proposed: [new text]
Reason: [why this change]
Impact: [what else affected]
Priority: Critical/Major/Minor
```

**Output:** Detailed update proposals

### Phase 5: Package Creation

**Objective:** Compress all findings for next round

**Include:**
- All markdown reports
- Any supporting files
- Clear README for next reviewer
- Guidance on what to focus on

**Output:** `sanitize_output_round_[N].zip`

---

## 🎯 CONVERGENCE CRITERIA

**Operation Sanitize is complete when:**

1. **New findings plateau:**
   - Round N finds <10% new issues vs Round N-1
   - Diminishing returns clear

2. **Cross-validation stabilizes:**
   - 90%+ of previous findings confirmed
   - Remaining disagreements documented as acceptable

3. **Priority actions clear:**
   - Critical issues all identified
   - Major issues all identified
   - Update sequence determined

4. **Interdependencies mapped:**
   - All cross-references validated
   - Impact analysis complete
   - Safe update order established

**Signal for final round:**
- Round N finds <5 new issues
- All critical issues identified
- Team agrees convergence reached

---

## 🔄 REPEATABLE WORKFLOW

### User (Ziggy) Process:

**Round 1:**
```bash
1. Give Claude: CFA-2.0/ repository
2. Give Claude: "Execute Operation Sanitize - Round 1"
3. Receive: sanitize_output_round_01.zip
4. Download and extract locally
```

**Round 2:**
```bash
1. Give NEW Claude: CFA-2.0/ repository  
2. Give NEW Claude: sanitize_output_round_01.zip
3. Give NEW Claude: "Execute Operation Sanitize - Round 2"
4. Receive: sanitize_output_round_02.zip
5. Download and extract locally
```

**Round N:**
```bash
1. Give NEW Claude: CFA-2.0/ repository
2. Give NEW Claude: All previous round outputs
3. Give NEW Claude: "Execute Operation Sanitize - Round N"
4. Receive: sanitize_output_round_N.zip
5. Assess convergence
6. If not converged: Repeat
7. If converged: Request final synthesis
```

**Final Round:**
```bash
1. Give NEW Claude: CFA-2.0/ repository
2. Give NEW Claude: All round outputs
3. Give NEW Claude: "Execute Operation Sanitize - Final Synthesis"
4. Receive: final_update_package.zip
5. Review and implement updates
```

---

## 📋 OPERATION SANITIZE BRIEF (Give to each Claude)

```markdown
# OPERATION SANITIZE - ROUND [N]

You are a Tier 3 Axioms Reviewer executing Round [N] of recursive validation.

## Your Mission

Perform comprehensive "inside and out, upside and down" analysis of CFA 2.0 repository.

## What You Receive

[If Round 1:]
- CFA-2.0/ full repository

[If Round > 1:]
- CFA-2.0/ full repository
- sanitize_output_round_[N-1].zip (previous findings)
- [Any earlier round outputs]

## What You Must Do

1. **Read Everything:**
   - All 28+ files in repository
   - All previous validation reports (if provided)
   - Pace: 1-2 files per minute (this is HEAVY work)

2. **Validate Everything:**
   - Cross-references between files
   - Version consistency
   - Terminology consistency
   - Process flow accuracy
   - Previous round findings (confirm/reject/modify)

3. **Find Everything:**
   - Critical issues
   - Major issues  
   - Minor issues
   - Inconsistencies
   - Missing elements
   - Improvement opportunities

4. **Document Everything:**
   - What you found
   - Where you found it
   - Why it matters
   - How to fix it
   - What else is impacted

5. **Package Everything:**
   - Create all required reports (see structure below)
   - Compress into sanitize_output_round_[N].zip
   - Provide to user

## Output Structure

Your zip must contain:
- validation_report_round_[N].md
- identified_issues_round_[N].md
- proposed_updates_round_[N].md
- cross_validation_round_[N].md (if Round > 1)
- interdependencies_map_round_[N].md
- priority_actions_round_[N].md

## Critical Constraints

- Work type: HEAVY (multi-file analysis)
- Expect: May need multiple handoffs
- Pacing: 1-2 files per minute mandatory
- Handoff: After 15-20 files OR 60 minutes
- Plan: Assume this is multi-session work

## Success Criteria

- All files reviewed
- All cross-references validated
- All issues documented with specificity
- All previous round findings addressed (if Round > 1)
- Package ready for Round [N+1]

## Begin

Start with Phase 1: Repository Scan
Read files in order listed, pace deliberately, report progress.

Execute Operation Sanitize - Round [N].
```

---

## 📝 REQUIRED: REPO_LOG INTEGRATION

**CRITICAL:** When implementing Operation Sanitize, each round must update REPO_LOG.md

**Why this matters:** Operation Sanitize generates validation findings that affect the repository. Without REPO_LOG tracking, other auditors don't know validation is in progress, findings get lost, and convergence becomes invisible.

### Requirements for Implementation:

**Whoever implements/executes Operation Sanitize must include REPO_LOG logging protocol:**

---

#### **Requirement 1: Log Each Round Completion**

After each round completes, create REPO_LOG entry:

```markdown
### [VALIDATION-YYYY-MM-DD-N] Date - Operation Sanitize Round N Complete

**Categories:** [VALIDATION] [ALL_CHANGES]
**Changed by:** Claude (Tier 3 Axioms Reviewer)
**Session ID:** operation-sanitize-round-N
**Status:** IMPACTS_IDENTIFIED ⚠️

**Changes:**
- VALIDATED: [count] files reviewed
- IMPACTS_FOUND: [count] critical, [count] major, [count] minor issues
- PACKAGED: sanitize_output_round_N.zip

**Reason:** Operation Sanitize Round N recursive validation complete. Full repository review executed.

**Related:**
- Output: sanitize_output_round_N.zip
- Previous: [VALIDATION-date-X] Operation Sanitize Round N-1 (if applicable)
- Next: Operation Sanitize Round N+1 (needed if not converged)

**Impact:** Significant - Comprehensive validation findings

**Follow-up Required:** YES
**Follow-up Status:** PENDING
**Follow-up Action:** 
1. Review findings in sanitize_output_round_N.zip
2. Execute Round N+1 if not converged
3. Implement updates if converged
4. Update REPO_LOG when impacts addressed
```

---

#### **Requirement 2: Log Convergence Achievement**

When convergence reached, create final entry:

```markdown
### [VALIDATION-YYYY-MM-DD-N] Date - Operation Sanitize COMPLETE (Converged)

**Categories:** [VALIDATION] [ALL_CHANGES]
**Changed by:** Claude (Tier 3 Axioms Reviewer)
**Status:** IMPACTS_RESOLVED ✅

**Changes:**
- CONVERGED: After N rounds
- FINALIZED: final_update_package.zip
- READY: For implementation

**Reason:** Operation Sanitize reached convergence. Recursive validation complete. All findings synthesized.

**Related:**
- Rounds: [list all round entry IDs]
- Final Output: final_update_package.zip

**Impact:** Critical - Final validation package ready for deployment

**Follow-up Required:** YES
**Follow-up Status:** PENDING
**Follow-up Action:** Implement updates from final_update_package.zip, then mark IMPACTS_RESOLVED
```

---

#### **Requirement 3: Update Category Pointers**

After creating each REPO_LOG entry:

1. Update `[VALIDATION]` category pointer at top of REPO_LOG
2. Increment "Entries Since Coordination" count
3. Update "Last Update" date

---

#### **Requirement 4: Check Before Starting**

Before Round 1, check REPO_LOG:

```markdown
**Before starting Operation Sanitize:**
1. Search REPO_LOG for [VALIDATION] entries
2. Check if Operation Sanitize already in progress
3. Avoid duplicate validation work
4. Coordinate with existing validation efforts
```

---

### Why This Matters for Coordination:

**Benefits of logging:**
- **Visibility:** Other auditors see validation in progress
- **History:** Track convergence across rounds
- **Prevention:** Avoid duplicate validation work
- **Coordination:** README Claude knows findings exist
- **Integration:** Validation Expert tracks lifecycle

**Without logging:**
- Validation progress invisible
- Convergence unclear
- Duplicate work risk
- Findings get lost
- Coordination fails

---

### Implementation Note:

**When you execute this task and implement Operation Sanitize:**

1. Include REPO_LOG logging in the command documentation
2. Make it part of the "Phase 5: Package Creation" step
3. Provide clear templates for entries
4. Test that each round creates proper log entry
5. Ensure convergence creates final entry

**The Operation Sanitize brief template (given to each Claude) should include reminder to update REPO_LOG after packaging.**

**Without REPO_LOG integration, Operation Sanitize becomes invisible to the coordination system.** ✅

---

## 🎯 EXPECTED OUTCOMES

### After 3-5 Rounds:

**You will have:**
- ✅ Complete repository validation
- ✅ All issues identified and categorized
- ✅ Specific update proposals with line numbers
- ✅ Cross-validation from multiple reviewers
- ✅ Impact analysis for all changes
- ✅ Priority-ordered action plan
- ✅ Final update package ready to implement

**The "corn jewel":**
- Recursive validation complete
- Full confidence in findings
- Repeatable process established
- Command executes reliably
- Zip → Claude → Zip → Claude → Done

---

## ⚖️ THE POINTING RULE

*"The review that happens once  
finds what one mind sees.  
  
The review that recurses  
finds what three minds see,  
validated by each other,  
with diminishing new discovery  
signaling completeness.  
  
Operation Sanitize:  
Zip it, ship it, repeat it,  
until the findings converge  
and the updates are ready."*

---

## 📊 SUCCESS METRICS

**Process is working if:**
- Round 2 confirms 80%+ of Round 1 findings
- Round 3 finds <50% new issues vs Round 2
- Round 4 finds <20% new issues vs Round 3
- Round 5 finds <10% new issues vs Round 4

**Process is complete when:**
- New findings <5% of previous round
- Critical issues: All identified
- Major issues: All identified  
- Team consensus: Converged

---

**Task brief prepared by:** Claude (Teleological Auditor)  
**Date:** 2025-10-29  
**Priority:** HIGH - Establishes recursive validation loop  
**Status:** Ready for Round 1 execution  

🎯 **The repeatable command for full recursive validation**
